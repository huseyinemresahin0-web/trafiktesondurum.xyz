# FastAPI backend (örnek placeholder)
from fastapi import FastAPI

app = FastAPI()

@app.get("/")
def home():
    return {"mesaj": "trafiktesondurum API çalışıyor"}
