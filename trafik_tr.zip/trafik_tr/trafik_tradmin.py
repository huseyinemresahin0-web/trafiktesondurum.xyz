# Streamlit admin panel (örnek placeholder)
import streamlit as st

st.title("trafiktesondurum Admin Panel")
st.write("Buradan kullanıcı ve abonelikleri yöneteceksiniz.")
